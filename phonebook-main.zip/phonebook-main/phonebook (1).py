#import all required packages
from tkinter import *
import tkinter.ttk as ttk
import pandas as pd
import tkinter.messagebox as tkMessageBox
import tkinter.font as tkFont

#This is the Mainmenu screen when the user logins this function will be called
def mainmenu(username):
    #Initate tkinter
    mainmenu_window = Tk()
    mainmenu_window.configure(background='#ADD8E6')
    mainmenu_window.title("PhoneBook")
    #setting window size
    width=600
    height=500
    screenwidth = mainmenu_window.winfo_screenwidth()
    screenheight = mainmenu_window.winfo_screenheight()
    alignstr = '%dx%d+%d+%d' % (width, height, (screenwidth - width) / 2, (screenheight - height) / 2)
    mainmenu_window.geometry(alignstr)
    mainmenu_window.resizable(width=False, height=False)
    #main heading
    main_heading=Label(mainmenu_window)
    ft = tkFont.Font(family='Times',size=28)
    main_heading["font"] = ft
    main_heading["bg"]="#ADD8E6"
    main_heading["fg"] = "#333333"
    main_heading["justify"] = "center"
    main_heading["text"] = "PHONE BOOK"
    main_heading.place(x=160,y=40,width=253,height=47)
    #sub heading
    sub_heading_contacts=Label(mainmenu_window)
    ft = tkFont.Font(family='Times',size=18)
    sub_heading_contacts["font"] = ft
    sub_heading_contacts["bg"]="#ADD8E6"
    sub_heading_contacts["fg"] = "#333333"
    sub_heading_contacts["justify"] = "left"
    sub_heading_contacts["text"] = "Contacts"
    sub_heading_contacts.place(x=0,y=120,width=210,height=56)
    #Button to add contacts
    b1=Button(mainmenu_window)
    b1["bg"] = "#efefef"
    ft = tkFont.Font(family='Times',size=16)
    b1["font"] = ft
    b1["fg"] = "#000000"
    b1["justify"] = "center"
    b1["text"] = "Add Contact"
    b1.place(x=60,y=190,width=164,height=46)
    b1["command"] = lambda: add_contact(username)
    #Button view contacts
    b2=Button(mainmenu_window)
    b2["bg"] = "#efefef"
    ft = tkFont.Font(family='Times',size=16)
    b2["font"] = ft
    b2["fg"] = "#000000"
    b2["justify"] = "center"
    b2["text"] = "View Contact"
    b2.place(x=300,y=190,width=164,height=47)
    b2["command"] = lambda: view_phonebook(username)
    #checking if user is admin or not the below logoc will work only if user is admin
    if username == "admin":
        sub_heading_user=Label(mainmenu_window)
        ft = tkFont.Font(family='Times',size=18)
        sub_heading_user["font"] = ft
        sub_heading_user["bg"]="#ADD8E6"
        sub_heading_user["fg"] = "#333333"
        sub_heading_user["justify"] = "left"
        sub_heading_user["text"] = "User Management"
        sub_heading_user.place(x=20,y=260,width=210,height=56)

        b3=Button(mainmenu_window)
        b3["bg"] = "#efefef"
        ft = tkFont.Font(family='Times',size=16)
        b3["font"] = ft
        b3["fg"] = "#000000"
        b3["justify"] = "center"
        b3["text"] = "Add User"
        b3.place(x=60,y=320,width=164,height=46)
        b3["command"] = add_user

        b4=Button(mainmenu_window)
        b4["bg"] = "#efefef"
        ft = tkFont.Font(family='Times',size=16)
        b4["font"] = ft
        b4["fg"] = "#000000"
        b4["justify"] = "center"
        b4["text"] = "View User"
        b4.place(x=300,y=320,width=164,height=46)
        b4["command"] = view_user
        mainmenu_window.mainloop()

#This is the Login Screen called at start
def login():
    #this function will very if valid user
    def login_database():
        login_df = pd.read_csv('login.csv')
        usernames = login_df['username'].unique().tolist()
        if e1.get() in usernames:
            password = login_df[login_df['username'] == e1.get()]['password'].values[0]
            if e2.get() == password:
                username = e1.get()
                login_window.destroy()
                mainmenu(username)
                
            else:
                l3.config(text="wrong password please try again")
        else:
            l3.config(text="user not found")
    # login_window.destroy()  #closes the login window

    login_window = Tk()
    login_window.title("PHONE BOOK")
    login_window["bg"] = "#add8e6"
    #setting window size
    width=600
    height=500
    screenwidth = login_window.winfo_screenwidth()
    screenheight = login_window.winfo_screenheight()
    alignstr = '%dx%d+%d+%d' % (width, height, (screenwidth - width) / 2, (screenheight - height) / 2)
    login_window.geometry(alignstr)
    login_window.resizable(width=False, height=False)

    main_heading=Label(login_window)
    ft = tkFont.Font(family='Times',size=28)
    main_heading["bg"] = "#add8e6"
    main_heading["font"] = ft
    main_heading["fg"] = "#333333"
    main_heading["justify"] = "center"
    main_heading["text"] = "PHONE BOOK"
    main_heading.place(x=170,y=0,width=253,height=47)

    sub_heading=Label(login_window)
    sub_heading["bg"] = "#add8e6"
    ft = tkFont.Font(family='Times',size=23)
    sub_heading["font"] = ft
    sub_heading["fg"] = "#333333"
    sub_heading["justify"] = "center"
    sub_heading["text"] = "Login"
    sub_heading.place(x=210,y=60,width=148,height=35)

    l1=Label(login_window)
    l1["bg"] = "#add8e6"
    ft = tkFont.Font(family='Times',size=18)
    l1["font"] = ft
    l1["fg"] = "#333333"
    l1["justify"] = "center"
    l1["text"] = "Username"
    l1.place(x=120,y=130,width=145,height=45)

    username = StringVar()
    e1=Entry(login_window,textvariable=username)
    e1["borderwidth"] = "1px"
    ft = tkFont.Font(family='Times',size=18)
    e1["font"] = ft
    e1["fg"] = "#333333"
    e1["justify"] = "left"
    e1["text"] = "username"
    e1.place(x=300,y=130,width=200,height=45)

    l2=Label(login_window)
    l2["bg"] = "#add8e6"
    ft = tkFont.Font(family='Times',size=18)
    l2["font"] = ft
    l2["fg"] = "#333333"
    l2["justify"] = "center"
    l2["text"] = "Password"
    l2.place(x=120,y=210,width=145,height=45)

    password = StringVar()
    e2=Entry(login_window,textvariable=password)
    e2["borderwidth"] = "1px"
    ft = tkFont.Font(family='Times',size=18)
    e2["font"] = ft
    e2["fg"] = "#333333"
    e2["justify"] = "left"
    e2["text"] = "Password"
    e2.place(x=300,y=210,width=200,height=45)
    e2["show"] = "*"

    b1=Button(login_window)
    b1["bg"] = "#efefef"
    ft = tkFont.Font(family='Times',size=18)
    b1["font"] = ft
    b1["fg"] = "#000000"
    b1["justify"] = "center"
    b1["text"] = "Login"
    b1.place(x=210,y=290,width=154,height=42)
    b1["command"] = login_database

    l3=Label(login_window)
    l3["bg"] = "#add8e6"
    ft = tkFont.Font(family='Times',size=18)
    l3["font"] = ft
    l3["fg"] = "#cc0000"
    l3["justify"] = "center"
    l3["text"] = ""
    l3.place(x=80,y=370,width=464,height=59)
    login_window.mainloop()
#tHIS IS THE SCREEN TO ADD USER 
def add_user():
    #this logic will add the user to csv
    def adduser_database():
        #read the login csv as dataframe
        login_df = pd.read_csv('login.csv')
        usernames = login_df["username"].tolist()
        if e1.get() == "" or e2.get() == "":
            l3.config(text="Fields are empty")
        elif e1.get() in usernames:
            l3.config(text="Username already exists")
        else:
            new_record = {
                "userid": login_df.iloc[-1]['userid']+1,
                "username":e1.get(),
                "password":e2.get(),
                "admin":False,
            }
            login_df = login_df.append(new_record, ignore_index = True)
            login_df.to_csv('login.csv',index=False)
            l3.config(text="Record Created")
            add_user_window.destroy()
            tkMessageBox.showinfo('', 'User Created')
    add_user_window = Tk()
    add_user_window.title("PHONE BOOK")
    add_user_window["bg"]="#ADD8E6"
    #setting window size
    width=600
    height=500
    screenwidth = add_user_window.winfo_screenwidth()
    screenheight = add_user_window.winfo_screenheight()
    alignstr = '%dx%d+%d+%d' % (width, height, (screenwidth - width) / 2, (screenheight - height) / 2)
    add_user_window.geometry(alignstr)
    add_user_window.resizable(width=False, height=False)

    main_heading=Label(add_user_window)
    ft = tkFont.Font(family='Times',size=28)
    main_heading["bg"]="#ADD8E6"
    main_heading["font"] = ft
    main_heading["fg"] = "#333333"
    main_heading["justify"] = "center"
    main_heading["text"] = "PHONE BOOK"
    main_heading.place(x=170,y=0,width=253,height=47)

    sub_heading=Label(add_user_window)
    sub_heading["bg"]="#ADD8E6"
    ft = tkFont.Font(family='Times',size=23)
    sub_heading["font"] = ft
    sub_heading["fg"] = "#333333"
    sub_heading["justify"] = "center"
    sub_heading["text"] = "Add User"
    sub_heading.place(x=210,y=60,width=148,height=35)

    l1=Label(add_user_window)
    l1["bg"]="#ADD8E6"
    ft = tkFont.Font(family='Times',size=18)
    l1["font"] = ft
    l1["fg"] = "#333333"
    l1["justify"] = "center"
    l1["text"] = "Username"
    l1.place(x=120,y=130,width=145,height=45)

    username = StringVar()
    e1=Entry(add_user_window,textvariable=username)
    e1["borderwidth"] = "1px"
    ft = tkFont.Font(family='Times',size=18)
    e1["font"] = ft
    e1["fg"] = "#333333"
    e1["justify"] = "left"
    e1["text"] = "username"
    e1.place(x=300,y=130,width=200,height=45)

    l2=Label(add_user_window)
    l2["bg"]="#ADD8E6"
    ft = tkFont.Font(family='Times',size=18)
    l2["font"] = ft
    l2["fg"] = "#333333"
    l2["justify"] = "center"
    l2["text"] = "Password"
    l2.place(x=120,y=210,width=145,height=45)

    password = StringVar()
    e2=Entry(add_user_window,textvariable=password)
    e2["borderwidth"] = "1px"
    ft = tkFont.Font(family='Times',size=18)
    e2["font"] = ft
    e2["fg"] = "#333333"
    e2["justify"] = "left"
    e2["text"] = "Password"
    e2.place(x=300,y=210,width=200,height=45)
    e2["show"] = "*"

    b1=Button(add_user_window)
    b1["bg"] = "#efefef"
    ft = tkFont.Font(family='Times',size=18)
    b1["font"] = ft
    b1["fg"] = "#000000"
    b1["justify"] = "center"
    b1["text"] = "Add User"
    b1.place(x=210,y=290,width=154,height=42)
    b1["command"] = adduser_database

    l3=Label(add_user_window)
    ft = tkFont.Font(family='Times',size=18)
    l3["bg"]="#ADD8E6"
    l3["font"] = ft
    l3["fg"] = "#cc0000"
    l3["justify"] = "center"
    l3["text"] = ""
    l3.place(x=80,y=370,width=464,height=59)

#tHIS IS THE SCREEN TO ADD contact 
def add_contact(username):
    #declare varaibles
    first_name = StringVar()
    last_name = StringVar()
    mobile = StringVar()
    work_phone = StringVar()
    fax = StringVar()
    email = StringVar()
    gender = StringVar()
    age = StringVar()
    def add_phonebook():
        phonebook_df = pd.read_csv('phonebook.csv')
        phoneook_df_user = phonebook_df[phonebook_df['username'] == username]
        if e1.get() == "" or e2.get() == "" or e3.get() == "" or e4.get() == "" or e5.get() == "" or e6.get() == "" or e8.get() == "":
            l9.config(text="Fields are empty")
        else:
            if phoneook_df_user.shape[0] > 0:
                no_of_records = phoneook_df_user[
                    (phoneook_df_user["first_name"] == e1.get()) & 
                    (phoneook_df_user["last_name"] == e2.get())
                ].shape[0]
            else:
                no_of_records = 0
            if no_of_records > 0:
                l9.config(text="Contact Exists with Same Name")
            else:
                new_record = {
                    'username': username,
                    'contactid': phonebook_df.iloc[-1]['contactid']+1,
                    'first_name': e1.get(),
                    'last_name': e2.get(),
                    'mobile': e3.get(),
                    'work_phone': e4.get(),
                    'fax': e5.get(),
                    'email': e6.get(),
                    'gender': gender,
                    'age': e8.get(),
                    }
                phonebook_df = phonebook_df.append(new_record, ignore_index = True)
                phonebook_df.to_csv('phonebook.csv',index=False)
            #execute message after account successfully created
            l9.config(text="Contact Saved") 
            add_contact_window.destroy()
            tkMessageBox.showinfo('', 'Contact Saved')
    add_contact_window = Tk()
    add_contact_window.title("PhoneBook")
    add_contact_window["bg"] = "#add8e6"
    #setting window size
    width=600
    height=600
    screenwidth = add_contact_window.winfo_screenwidth()
    screenheight = add_contact_window.winfo_screenheight()
    alignstr = '%dx%d+%d+%d' % (width, height, (screenwidth - width) / 2, (screenheight - height) / 2)
    add_contact_window.geometry(alignstr)
    add_contact_window.resizable(width=False, height=False)

    main_heading=Label(add_contact_window)
    main_heading["bg"] = "#add8e6"
    ft = tkFont.Font(family='Times',size=28)
    main_heading["font"] = ft
    main_heading["fg"] = "#333333"
    main_heading["justify"] = "center"
    main_heading["text"] = "Phone Book"
    main_heading.place(x=150,y=0,width=300,height=70)

    sub_heading=Label(add_contact_window)
    sub_heading["bg"] = "#add8e6"
    ft = tkFont.Font(family='Times',size=18)
    sub_heading["font"] = ft
    sub_heading["fg"] = "#333333"
    sub_heading["justify"] = "center"
    sub_heading["text"] = "Add Contact"
    sub_heading.place(x=210,y=50,width=171,height=65)

    l1=Label(add_contact_window)
    l1["bg"] = "#add8e6"
    ft = tkFont.Font(family='Times',size=13)
    l1["font"] = ft
    l1["fg"] = "#333333"
    l1["justify"] = "left"
    l1["text"] = "First Name"
    l1.place(x=130,y=120,width=170,height=40)

    l2=Label(add_contact_window)
    l2["bg"] = "#add8e6"
    ft = tkFont.Font(family='Times',size=13)
    l2["font"] = ft
    l2["fg"] = "#333333"
    l2["justify"] = "left"
    l2["text"] = "Last Name"
    l2.place(x=130,y=160,width=170,height=40)

    l3=Label(add_contact_window)
    l3["bg"] = "#add8e6"
    ft = tkFont.Font(family='Times',size=13)
    l3["font"] = ft
    l3["fg"] = "#333333"
    l3["justify"] = "left"
    l3["text"] = "Mobile"
    l3.place(x=130,y=200,width=170,height=40)

    l4=Label(add_contact_window)
    l4["bg"] = "#add8e6"
    ft = tkFont.Font(family='Times',size=13)
    l4["font"] = ft
    l4["fg"] = "#333333"
    l4["justify"] = "left"
    l4["text"] = "Work Phone"
    l4.place(x=130,y=240,width=170,height=40)

    l5=Label(add_contact_window)
    l5["bg"] = "#add8e6"
    ft = tkFont.Font(family='Times',size=13)
    l5["font"] = ft
    l5["fg"] = "#333333"
    l5["justify"] = "left"
    l5["text"] = "Fax"
    l5.place(x=130,y=280,width=170,height=40)

    l6=Label(add_contact_window)
    l6["bg"] = "#add8e6"
    ft = tkFont.Font(family='Times',size=13)
    l6["font"] = ft
    l6["fg"] = "#333333"
    l6["justify"] = "left"
    l6["text"] = "Email"
    l6.place(x=130,y=320,width=170,height=40)

    l7=Label(add_contact_window)
    l7["bg"] = "#add8e6"
    ft = tkFont.Font(family='Times',size=13)
    l7["font"] = ft
    l7["fg"] = "#333333"
    l7["justify"] = "left"
    l7["text"] = "Gender"
    l7.place(x=130,y=360,width=170,height=40)

    l8=Label(add_contact_window)
    l8["bg"] = "#add8e6"
    ft = tkFont.Font(family='Times',size=13)
    l8["font"] = ft
    l8["fg"] = "#333333"
    l8["justify"] = "left"
    l8["text"] = "Age"
    l8.place(x=130,y=400,width=170,height=40)

    l9=Label(add_contact_window)
    ft = tkFont.Font(family='Times',size=23)
    l9["bg"] = "#add8e6"
    l9["font"] = ft
    l9["fg"] = "#cc0000"
    l9["justify"] = "center"
    l9["text"] = ""
    l9.place(x=130,y=510,width=340,height=40)

    e1=Entry(add_contact_window,textvariable=first_name)
    e1["borderwidth"] = "1px"
    ft = tkFont.Font(family='Times',size=13)
    e1["font"] = ft
    e1["fg"] = "#333333"
    e1["justify"] = "left"
    e1["text"] = ""
    e1.place(x=300,y=120,width=170,height=40)

    e2=Entry(add_contact_window,textvariable=last_name)
    e2["borderwidth"] = "1px"
    ft = tkFont.Font(family='Times',size=13)
    e2["font"] = ft
    e2["fg"] = "#333333"
    e2["justify"] = "left"
    e2["text"] = ""
    e2.place(x=300,y=160,width=170,height=40)

    e3=Entry(add_contact_window,textvariable=mobile)
    e3["borderwidth"] = "1px"
    ft = tkFont.Font(family='Times',size=13)
    e3["font"] = ft
    e3["fg"] = "#333333"
    e3["justify"] = "left"
    e3["text"] = ""
    e3.place(x=300,y=200,width=170,height=40)

    e4=Entry(add_contact_window,textvariable=work_phone)
    e4["borderwidth"] = "1px"
    ft = tkFont.Font(family='Times',size=13)
    e4["font"] = ft
    e4["fg"] = "#333333"
    e4["justify"] = "left"
    e4["text"] = ""
    e4.place(x=300,y=240,width=170,height=40)

    e5=Entry(add_contact_window,textvariable=fax)
    e5["borderwidth"] = "1px"
    ft = tkFont.Font(family='Times',size=13)
    e5["font"] = ft
    e5["fg"] = "#333333"
    e5["justify"] = "left"
    e5["text"] = ""
    e5.place(x=300,y=280,width=170,height=40)

    e6=Entry(add_contact_window,textvariable=email)
    e6["borderwidth"] = "1px"
    ft = tkFont.Font(family='Times',size=13)
    e6["font"] = ft
    e6["fg"] = "#333333"
    e6["justify"] = "left"
    e6["text"] = ""
    e6.place(x=300,y=320,width=170,height=40)

    e7_1=Radiobutton(add_contact_window,variable=gender)
    ft = tkFont.Font(family='Times',size=13)
    e7_1["bg"] = "#add8e6"
    e7_1["font"] = ft
    e7_1["fg"] = "#333333"
    e7_1["justify"] = "center"
    e7_1["text"] = "Male"
    e7_1["value"] = "Male"
    e7_1.place(x=300,y=360,width=70,height=40)

    e7_2=Radiobutton(add_contact_window,variable=gender)
    ft = tkFont.Font(family='Times',size=13)
    e7_2["bg"] = "#add8e6"
    e7_2["font"] = ft
    e7_2["fg"] = "#333333"
    e7_2["justify"] = "right"
    e7_2["text"] = "Female"
    e7_2["value"] = "Female"
    e7_2.place(x=380,y=360,width=70,height=40)

    e8=Entry(add_contact_window,textvariable=age)
    e8["borderwidth"] = "1px"
    ft = tkFont.Font(family='Times',size=13)
    e8["font"] = ft
    e8["fg"] = "#333333"
    e8["justify"] = "left"
    e8["text"] = ""
    e8.place(x=300,y=400,width=170,height=40)

    b1=Button(add_contact_window)
    b1["bg"] = "#efefef"
    ft = tkFont.Font(family='Times',size=10)
    b1["font"] = ft
    b1["fg"] = "#000000"
    b1["justify"] = "center"
    b1["text"] = "Add User"
    b1.place(x=240,y=450,width=120,height=40)
    b1["command"] = add_phonebook

#tHIS IS THE SCREEN TO view USER 
def view_user():
    #logic to delect user
    def DeleteData():
        if not tree.selection():
            result = tkMessageBox.showwarning('', 'Please Select Something First!', icon="warning")
        else:
            result = tkMessageBox.askquestion('', 'Are you sure you want to delete this record?', icon="warning")
            if result == 'yes':
                curItem = tree.focus()
                contents =(tree.item(curItem))
                selecteditem = contents['values']
                tree.delete(curItem)
                logindf = pd.read_csv("login.csv", index_col ="userid")
                logindf.drop([selecteditem[0]],inplace=True)
                logindf.to_csv('login.csv',index=True)

    view_user_window = Tk() #creates a new window for signup process
    width = 700
    height = 600
    screen_width = view_user_window.winfo_screenwidth()
    screen_height = view_user_window.winfo_screenheight()
    x = (screen_width/2) - (width/2)
    y = (screen_height/2) - (height/2)
    view_user_window.geometry("%dx%d+%d+%d" % (width, height, x, y))
    view_user_window.resizable(0, 0)
    view_user_window.config(bg="#ADD8E6")
    view_user_window.title("Users") #title for the window
    Top = Frame(view_user_window, width=500, bd=1, relief=SOLID)
    Top.pack(side=TOP)
    Mid = Frame(view_user_window, width=500,  bg="#ADD8E6")
    Mid.pack(side=TOP)
    MidLeft = Frame(Mid, width=100)
    MidLeft.pack(side=LEFT, pady=10)
    MidLeftPadding = Frame(Mid, width=370)
    MidLeftPadding.pack(side=LEFT)
    MidRight = Frame(Mid, width=100)
    MidRight.pack(side=RIGHT, pady=10)
    TableMargin = Frame(view_user_window, width=500)
    TableMargin.pack(side=TOP)
    btn_add = Button(MidLeft, text="Add User", command=add_user)
    btn_add.pack()
    btn_delete = Button(MidRight, text="Delete User", command=DeleteData)
    btn_delete.pack(side=RIGHT)
    scrollbarx = Scrollbar(TableMargin, orient=HORIZONTAL)
    scrollbary = Scrollbar(TableMargin, orient=VERTICAL)
    tree = ttk.Treeview(TableMargin, columns=("Userid","Username"),height=400, selectmode="extended", yscrollcommand=scrollbary.set, xscrollcommand=scrollbarx.set)
    scrollbary.config(command=tree.yview)
    scrollbary.pack(side=RIGHT, fill=Y)
    scrollbarx.config(command=tree.xview)
    scrollbarx.pack(side=BOTTOM, fill=X)
    tree.heading('Userid', text="Userid", anchor=W)
    tree.heading('Username', text="Username", anchor=W)
    tree.column('#0', stretch=NO, minwidth=0, width=10)
    tree.column('#1', stretch=NO, minwidth=0, width=40)
    login_df = pd.read_csv('login.csv')
    for i in range(len(login_df)):
        data = (
            login_df.iloc[i, 0],
            login_df.iloc[i, 1],
        )
        print(data)
        tree.insert('', 'end', values=(data))
    tree.pack()

#tHIS IS THE SCREEN TO view contact 
def view_phonebook(username):
    #this is logic to search records
    def search_records():
        phonebook_df = pd.read_csv('phonebook.csv')
        print(f"username: {username}")
        phoneook_df_user = phonebook_df[phonebook_df['username'] == username]
        print(phoneook_df_user.shape[0])
        if phoneook_df_user.shape[0] > 0:
            for i in range(len(phoneook_df_user)) :
                data = (
                    phoneook_df_user.iloc[i, 0],
                    phoneook_df_user.iloc[i, 2],
                    phoneook_df_user.iloc[i, 3],
                    phoneook_df_user.iloc[i, 4],
                    phoneook_df_user.iloc[i, 5],
                    phoneook_df_user.iloc[i, 6],
                    phoneook_df_user.iloc[i, 7],
                    phoneook_df_user.iloc[i, 8],
                    phoneook_df_user.iloc[i, 9],
                )
                print(data)
                tree.insert('', 'end', values=(data))
        else:
            print("test")
    #this is the Screen to update record
    def OnSelected(event):
        #logic to update record
        def update_phonebook(contactid):
            phonebook_df = pd.read_csv("phonebook.csv")
            data = [e1.get(),e2.get(),e3.get(),e4.get(),e5.get(),e6.get(),e8.get()]
            phonebook_df.loc[phonebook_df['contactid'] == contactid,['first_name','last_name','mobile','work_phone','fax','email','age']]=data
            phonebook_df.to_csv('phonebook.csv',index=False)
            selected_phonebook_window.destroy()
            tkMessageBox.showinfo('', 'Contact Updated')
        print("test")
        curItem = tree.focus()
        contents =(tree.item(curItem))
        selecteditem = contents['values']
        print(selecteditem)
        first_name = StringVar()
        last_name = StringVar()
        mobile = StringVar()
        work_phone = StringVar()
        fax = StringVar()
        email = StringVar()
        gender = StringVar()
        age = StringVar()
        selected_phonebook_window = Tk()
        selected_phonebook_window.title("PhoneBook")
        selected_phonebook_window["bg"] = "#add8e6"
        #setting window size
        width=600
        height=600
        screenwidth = selected_phonebook_window.winfo_screenwidth()
        screenheight = selected_phonebook_window.winfo_screenheight()
        alignstr = '%dx%d+%d+%d' % (width, height, (screenwidth - width) / 2, (screenheight - height) / 2)
        selected_phonebook_window.geometry(alignstr)
        selected_phonebook_window.resizable(width=False, height=False)

        main_heading=Label(selected_phonebook_window)
        main_heading["bg"] = "#add8e6"
        ft = tkFont.Font(family='Times',size=28)
        main_heading["font"] = ft
        main_heading["fg"] = "#333333"
        main_heading["justify"] = "center"
        main_heading["text"] = "Phone Book"
        main_heading.place(x=150,y=0,width=300,height=70)

        sub_heading=Label(selected_phonebook_window)
        sub_heading["bg"] = "#add8e6"
        ft = tkFont.Font(family='Times',size=18)
        sub_heading["font"] = ft
        sub_heading["fg"] = "#333333"
        sub_heading["justify"] = "center"
        sub_heading["text"] = "Update Contact"
        sub_heading.place(x=210,y=50,width=171,height=65)

        l1=Label(selected_phonebook_window)
        l1["bg"] = "#add8e6"
        ft = tkFont.Font(family='Times',size=13)
        l1["font"] = ft
        l1["fg"] = "#333333"
        l1["justify"] = "left"
        l1["text"] = "First Name"
        l1.place(x=130,y=120,width=170,height=40)

        l2=Label(selected_phonebook_window)
        l2["bg"] = "#add8e6"
        ft = tkFont.Font(family='Times',size=13)
        l2["font"] = ft
        l2["fg"] = "#333333"
        l2["justify"] = "left"
        l2["text"] = "Last Name"
        l2.place(x=130,y=160,width=170,height=40)

        l3=Label(selected_phonebook_window)
        l3["bg"] = "#add8e6"
        ft = tkFont.Font(family='Times',size=13)
        l3["font"] = ft
        l3["fg"] = "#333333"
        l3["justify"] = "left"
        l3["text"] = "Mobile"
        l3.place(x=130,y=200,width=170,height=40)

        l4=Label(selected_phonebook_window)
        l4["bg"] = "#add8e6"
        ft = tkFont.Font(family='Times',size=13)
        l4["font"] = ft
        l4["fg"] = "#333333"
        l4["justify"] = "left"
        l4["text"] = "Work Phone"
        l4.place(x=130,y=240,width=170,height=40)

        l5=Label(selected_phonebook_window)
        l5["bg"] = "#add8e6"
        ft = tkFont.Font(family='Times',size=13)
        l5["font"] = ft
        l5["fg"] = "#333333"
        l5["justify"] = "left"
        l5["text"] = "Fax"
        l5.place(x=130,y=280,width=170,height=40)

        l6=Label(selected_phonebook_window)
        l6["bg"] = "#add8e6"
        ft = tkFont.Font(family='Times',size=13)
        l6["font"] = ft
        l6["fg"] = "#333333"
        l6["justify"] = "left"
        l6["text"] = "Email"
        l6.place(x=130,y=320,width=170,height=40)

        l7=Label(selected_phonebook_window)
        l7["bg"] = "#add8e6"
        ft = tkFont.Font(family='Times',size=13)
        l7["font"] = ft
        l7["fg"] = "#333333"
        l7["justify"] = "left"
        l7["text"] = "Gender"
        l7.place(x=130,y=360,width=170,height=40)

        l8=Label(selected_phonebook_window)
        l8["bg"] = "#add8e6"
        ft = tkFont.Font(family='Times',size=13)
        l8["font"] = ft
        l8["fg"] = "#333333"
        l8["justify"] = "left"
        l8["text"] = "Age"
        l8.place(x=130,y=400,width=170,height=40)

        l9=Label(selected_phonebook_window)
        ft = tkFont.Font(family='Times',size=23)
        l9["bg"] = "#add8e6"
        l9["font"] = ft
        l9["fg"] = "#cc0000"
        l9["justify"] = "center"
        l9["text"] = ""
        l9.place(x=130,y=510,width=340,height=40)

        e1=Entry(selected_phonebook_window,textvariable=first_name)
        e1["borderwidth"] = "1px"
        ft = tkFont.Font(family='Times',size=13)
        e1["font"] = ft
        e1["fg"] = "#333333"
        e1["justify"] = "left"
        e1["text"] = ""
        e1.place(x=300,y=120,width=170,height=40)

        e2=Entry(selected_phonebook_window,textvariable=last_name)
        e2["borderwidth"] = "1px"
        ft = tkFont.Font(family='Times',size=13)
        e2["font"] = ft
        e2["fg"] = "#333333"
        e2["justify"] = "left"
        e2["text"] = ""
        e2.place(x=300,y=160,width=170,height=40)

        e3=Entry(selected_phonebook_window,textvariable=mobile)
        e3["borderwidth"] = "1px"
        ft = tkFont.Font(family='Times',size=13)
        e3["font"] = ft
        e3["fg"] = "#333333"
        e3["justify"] = "left"
        e3["text"] = ""
        e3.place(x=300,y=200,width=170,height=40)

        e4=Entry(selected_phonebook_window,textvariable=work_phone)
        e4["borderwidth"] = "1px"
        ft = tkFont.Font(family='Times',size=13)
        e4["font"] = ft
        e4["fg"] = "#333333"
        e4["justify"] = "left"
        e4["text"] = ""
        e4.place(x=300,y=240,width=170,height=40)

        e5=Entry(selected_phonebook_window,textvariable=fax)
        e5["borderwidth"] = "1px"
        ft = tkFont.Font(family='Times',size=13)
        e5["font"] = ft
        e5["fg"] = "#333333"
        e5["justify"] = "left"
        e5["text"] = ""
        e5.place(x=300,y=280,width=170,height=40)

        e6=Entry(selected_phonebook_window,textvariable=email)
        e6["borderwidth"] = "1px"
        ft = tkFont.Font(family='Times',size=13)
        e6["font"] = ft
        e6["fg"] = "#333333"
        e6["justify"] = "left"
        e6["text"] = ""
        e6.place(x=300,y=320,width=170,height=40)

        e7_1=Radiobutton(selected_phonebook_window,variable=gender)
        ft = tkFont.Font(family='Times',size=13)
        e7_1["bg"] = "#add8e6"
        e7_1["font"] = ft
        e7_1["fg"] = "#333333"
        e7_1["justify"] = "center"
        e7_1["text"] = "Male"
        e7_1["value"] = "Male"
        e7_1.place(x=300,y=360,width=70,height=40)

        e7_2=Radiobutton(selected_phonebook_window,variable=gender)
        ft = tkFont.Font(family='Times',size=13)
        e7_2["bg"] = "#add8e6"
        e7_2["font"] = ft
        e7_2["fg"] = "#333333"
        e7_2["justify"] = "right"
        e7_2["text"] = "Female"
        e7_2["value"] = "Female"
        e7_2.place(x=380,y=360,width=70,height=40)

        e8=Entry(selected_phonebook_window,textvariable=age)
        e8["borderwidth"] = "1px"
        ft = tkFont.Font(family='Times',size=13)
        e8["font"] = ft
        e8["fg"] = "#333333"
        e8["justify"] = "left"
        e8["text"] = ""
        e8.place(x=300,y=400,width=170,height=40)

        b1=Button(selected_phonebook_window)
        b1["bg"] = "#efefef"
        ft = tkFont.Font(family='Times',size=10)
        b1["font"] = ft
        b1["fg"] = "#000000"
        b1["justify"] = "center"
        b1["text"] = "Update Contact"
        b1.place(x=240,y=450,width=120,height=40)
        b1["command"] = lambda: update_phonebook(selecteditem[0])
        e1.insert(0,selecteditem[1])
        e2.insert(0,selecteditem[2])
        e3.insert(0,selecteditem[3])
        e4.insert(0,selecteditem[4])
        e5.insert(0,selecteditem[5])
        e6.insert(0,selecteditem[6])
        e8.insert(0,selecteditem[8])
        selected_phonebook_window.mainloop()
    #logic to delect record
    def DeleteContact():
        if not tree.selection():
            result = tkMessageBox.showwarning('', 'Please Select Something First!', icon="warning")
        else:
            result = tkMessageBox.askquestion('', 'Are you sure you want to delete this record?', icon="warning")
            if result == 'yes':
                curItem = tree.focus()
                contents =(tree.item(curItem))
                selecteditem = contents['values']
                tree.delete(curItem)
                phonebook_df = pd.read_csv("phonebook.csv", index_col ="contactid")
                phonebook_df.drop([selecteditem[0]],inplace=True)
                phonebook_df.to_csv('phonebook.csv',index=True)

    view_contact_window = Tk() #creates a new window for signup process
    width = 700
    height = 600
    screen_width = view_contact_window.winfo_screenwidth()
    screen_height = view_contact_window.winfo_screenheight()
    x = (screen_width/2) - (width/2)
    y = (screen_height/2) - (height/2)
    view_contact_window.geometry("%dx%d+%d+%d" % (width, height, x, y))
    view_contact_window.resizable(0, 0)
    view_contact_window.config(bg="#ADD8E6")
    view_contact_window.title("Users") #title for the window
    Top = Frame(view_contact_window, width=500, bd=1, relief=SOLID)
    Top.pack(side=TOP)
    Mid = Frame(view_contact_window, width=500,  bg="#ADD8E6")
    Mid.pack(side=TOP)
    MidLeft = Frame(Mid, width=100)
    MidLeft.pack(side=LEFT, pady=10)
    MidLeftPadding = Frame(Mid, width=370)
    MidLeftPadding.pack(side=LEFT)
    MidRight = Frame(Mid, width=100)
    MidRight.pack(side=RIGHT, pady=10)
    TableMargin = Frame(view_contact_window, width=500)
    TableMargin.pack(side=TOP)
    btn_add = Button(MidLeft, text="Add Contact", command=add_contact)
    btn_add.pack()
    btn_delete = Button(MidRight, text="Delete Contact", command=DeleteContact)
    btn_delete.pack(side=RIGHT)
    scrollbarx = Scrollbar(TableMargin, orient=HORIZONTAL)
    scrollbary = Scrollbar(TableMargin, orient=VERTICAL)
    tree = ttk.Treeview(TableMargin, columns=("ContactID","FirstName", "LastName", "Mobile", "WorkPhone", "Fax", "Email", "Gender","Age"),height=400, selectmode="extended", yscrollcommand=scrollbary.set, xscrollcommand=scrollbarx.set)
    scrollbary.config(command=tree.yview)
    scrollbary.pack(side=RIGHT, fill=Y)
    scrollbarx.config(command=tree.xview)
    scrollbarx.pack(side=BOTTOM, fill=X)
    tree.heading('ContactID', text="ContactID", anchor=W)
    tree.heading('FirstName', text="FirstName", anchor=W)
    tree.heading('LastName', text="LastName", anchor=W)
    tree.heading('Mobile', text="Mobile", anchor=W)
    tree.heading('WorkPhone', text="WorkPhone", anchor=W)
    tree.heading('Fax', text="Fax", anchor=W)
    tree.heading('Email', text="Email", anchor=W)
    tree.heading('Gender', text="Gender", anchor=W)
    tree.heading('Age', text="Age", anchor=W)
    tree.column('#0', stretch=NO, minwidth=0, width=10)
    tree.column('#1', stretch=NO, minwidth=0, width=40)
    tree.column('#2', stretch=NO, minwidth=0, width=40)
    tree.column('#3', stretch=NO, minwidth=0, width=40)
    tree.column('#4', stretch=NO, minwidth=0, width=40)
    tree.column('#5', stretch=NO, minwidth=0, width=40)
    tree.column('#6', stretch=NO, minwidth=0, width=40)
    tree.column('#7', stretch=NO, minwidth=0, width=40)
    tree.column('#8', stretch=NO, minwidth=0, width=40)
    tree.pack()
    tree.bind('<Double-Button-1>', OnSelected)
    search_records()


# mainmenu("admin")
login()
